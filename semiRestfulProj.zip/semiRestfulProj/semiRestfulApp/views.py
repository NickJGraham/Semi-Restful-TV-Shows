from django.shortcuts import render, redirect
from .models import *

def index(request):
    context={
        "all_shows": Show.objects.all()
    }
    return render(request, "index.html", context)

# Add a show
def add_show(request):
    return render(request, "addshow.html")

# Submit a show to db
def submit_show(request):
    errors = Show.objects.basic_validator(request.POST)
    if len(errors) > 0:
        return redirect ("/add_show")

    else:
        Show.objects.create(title=request.POST['title'], network=request.POST['network'], release_date=request.POST['release_date'], desc=request.POST['desc'])
        return redirect("/shows")

# Show details of a specific show
def display_show(request, id):
    context = {
        "show": Show.objects.get(id=id)
    }
    return render(request, "showInfo.html", context)

# Edit a show
def edit_show(request, id):
    # print(Show.objects.get(id=id).release_date)
    context = {
        "show": Show.objects.get(id=id),
        "date": str(Show.objects.get(id=id).release_date)
    }
    # print(context["show"].release_date)
    return render(request, "showEdit.html", context)

# Submit an edit
def submit_edit(request, id):
    errors = Show.objects.basic_validator(request.POST)
    selected = Show.objects.get(id=id)
    if len(errors) > 0:
        return redirect(f"/edit_show/{id}")

    else:
        if request.POST['title']:
            selected.title = request.POST['title']
        
        if request.POST['network']:
            selected.network = request.POST['network']
        
        if request.POST['release_date']:
            selected.release_date = request.POST['release_date']
        
        if request.POST['desc']:
            selected.desc = request.POST['desc']
        selected.save()
        return redirect("/shows")

# Delete a show
def delete_show(request, id):
    Show.objects.get(id=id).delete()
    return redirect("/shows")

