from django.urls import path     
from . import views
urlpatterns = [
    path('', views.add_show),
    path('shows', views.index),
    path('add_show', views.add_show),
    path('submit_show', views.submit_show),
    path('display_show/<id>', views.display_show),
    path('edit_show/<id>', views.edit_show),
    path('submit_edit/<id>', views.submit_edit),
    path('delete_show/<id>', views.delete_show),
]