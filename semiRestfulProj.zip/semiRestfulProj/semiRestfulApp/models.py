from django.db import models
from datetime import date, datetime

class ShowManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['title']) < 2:
            errors['title'] = 'This field must be at least two characters!'
        if len(postData['network']) < 3:
            errors['network'] = 'This field must be at least three characters!'
        if len(postData['desc']) < 10:
            errors['desc'] = 'Description must be at least ten characters!'
        if len(postData["release_date"]) > 0 and datetime.strptime(postData["release_date"], '%Y-%m-%d') > datetime.today() :
            errors["release_date"] = "Invalid release date."
        return errors

class Show(models.Model):
    title = models.CharField(max_length=60)
    network = models.CharField(max_length=60)
    release_date = models.DateField()
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ShowManager()

def __repr__(self):
    return f"Title: {self.title} | Network: {self.network}"

